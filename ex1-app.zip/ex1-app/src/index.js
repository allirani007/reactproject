import React from "react";
import  ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
// const user=[1,2,3,4];

// const ele =<p>{user.map((u)=>(<li>{u}</li>))}</p>


// function App(props)
//     {
//         console.log(props);
//         return<p>hello app! function</p>;
//     }

//ReactDOM.render(<App name={"alli"} fname={"suresh"} age={40} rolno={[1,2,3,4,5,6,7,8]}/>,document.getElementById("root"));
ReactDOM.render(<App />,document.getElementById("root"));